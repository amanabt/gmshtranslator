from __future__ import print_function

print ("gmshtranslator friendly reminder: rules and actions prototypes\n\n")
print ("def node_condition(tag,x,y,z,physgroups): ")
print ("def node_action(tag,x,y,z):")
print ("def element_condition(eletag,eletype,physgrp,nodes):")
print ("def element_action(eletag,eletype,physgrp,nodes):")
